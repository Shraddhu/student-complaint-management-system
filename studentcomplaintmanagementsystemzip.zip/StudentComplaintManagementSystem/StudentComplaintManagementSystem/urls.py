"""StudentComplaintManagementSystem URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.contrib import admin
from django.urls import path
from studentcomplaint.views import *
urlpatterns = [
    path('admin/', admin.site.urls),
    path('', index,name='index'),
    path('registration/',registration,name='registration'),
    path('student_login/',student_login,name='student_login'),
    path('student_home/',student_home,name='student_home'),
    path('profile/',profile,name='profile'),
    path('logout/',Logout,name='logout'),
    path('admin_login/',admin_login,name='admin_login'),
    path('current_year/',current_year,name='current_year'),
    path('edit_year/',edit_year,name='edit_year'),
    path('student_suggestion/',student_suggestion,name='student_suggestion'),
    path('edit_suggestion/',edit_studentsuggestion,name='edit_suggestion'),
    path('change_password/',change_password,name='change_password'),
    path('admin_home/',admin_home,name='admin_home'),
    path('change_passwordadmin/',change_passwordadmin,name='change_passwordadmin'),
    path('all_student/',all_student,name='all_student'),
    path('delete_student/<int:pid>',delete_student,name='delete_student'),
    path('edit_profile/<int:pid>',edit_profile,name='edit_profile'),
]
