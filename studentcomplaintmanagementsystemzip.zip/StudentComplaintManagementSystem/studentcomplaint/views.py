from django.shortcuts import render ,redirect
from .models import *
from django.contrib.auth import login,logout,authenticate
# Create your views here.
def index(request):
    return render(request,'index.html')

def registration(request):
    error =""
    if request.method == "POST":
        fn = request.POST['firstname']
        ln = request.POST['lastname']
        si = request.POST['student_id']
        em = request.POST['email']
        pwd = request.POST['pwd']
        try:
            user = User.objects.create_user(first_name=fn, last_name=ln,username=em,password=pwd)
            Student_Complaint.objects.create(user = user,student_id=si)
            StudentCurrentYear.objects.create(user=user)
            StudentSuggestion.objects.create(user=user)


            error="no"
        except:
            error="yes"


    return render(request,'registration.html',locals())

def student_login(request):
    error =""
    if request.method== 'POST':
        u = request.POST['emailid']
        p = request.POST['password']
        user = authenticate(username=u,password=p)
        if user:
            login(request,user)
            error = "no"
        else:
            error = "yes"
    return render(request,'student_login.html',locals())

def student_home(request):
    if not request.user.is_authenticated:
        return redirect('student_login')
    return render(request,'student_home.html')

def Logout(request):
    logout(request)
    return redirect('index')

def profile(request):
    if not request.user.is_authenticated:
        return redirect('student_login')
    error =""
    user= request.user
    student= Student_Complaint.objects.get(user=user)
    if request.method == "POST":
        fn = request.POST['firstname']
        ln = request.POST['lastname']
        si = request.POST['student_id']
        dept = request.POST['department']
        contact = request.POST['contact']
        studentcomplaint = request.POST['studentcomplaint']
        gender = request.POST['gender']

        student.user.first_name = fn
        student.user.last_name = ln
        student.user.student_id = si
        student.user.studentdept = dept
        student.user.contact = contact
        student.user.gender = gender

        if studentcomplaint:
            student.Student_complaint = studentcomplaint
        try:
            student.save()
            student.user.save()
            error = "no"
        except:
            error="yes"


    return render(request,'profile.html',locals())

def admin_login(request):
    return render(request,'admin_login.html')

def current_year(request):
    if not request.user.is_authenticated:
        return redirect('student_login')
    user= request.user
    year= StudentCurrentYear.objects.get(user=user)

    return render(request,'current_year.html',locals())

def edit_year(request):
    if not request.user.is_authenticated:
        return redirect('student_login')
    error =""
    user= request.user
    year= StudentCurrentYear.objects.get(user=user)
    if request.method == "POST":
        collegename= request.POST['collegename']
        studentcourse= request.POST['studentcourse']
        studentdiv= request.POST['studentdiv']


        year.user.collegename =collegename
        year.user.studentcourse =studentcourse
        year.user.studentdiv=studentdiv



        try:
            year.save()
            error = "no"
        except:
            error="yes"


    return render(request,'edit_year.html',locals())

def student_suggestion(request):
    if not request.user.is_authenticated:
        return redirect('student_login')
    user= request.user
    suggestion= StudentSuggestion.objects.get(user=user)

    return render(request,'student_suggestion.html',locals())

def edit_studentsuggestion(request):
    if not request.user.is_authenticated:
        return redirect('student_login')
    error =""
    user= request.user
    suggestion=StudentSuggestion.objects.get(user=user)
    if request.method == "POST":

        studentcourse= request.POST['studentcourse']
        studentsuggestion= request.POST['studentsuggestion']



        suggestion.user.studentcourse=studentcourse
        suggestion.user.studentsuggestion=studentsuggestion



        try:
            suggestion.save()
            error = "no"
        except:
            error="yes"


    return render(request,'edit_suggestion.html',locals())

def student_suggestion(request):
    if not request.user.is_authenticated:
        return redirect('student_login')
    user= request.user
    suggestion= StudentSuggestion.objects.get(user=user)

    return render(request,'student_suggestion.html',locals())

def change_password(request):
    if not request.user.is_authenticated:
        return redirect('admin_login')
    error =""

    user = request.user
    if request.method == "POST":
        c= request.POST['currentpassword']
        n= request.POST['newpassword']
        try:
            if user.check_password(c):
               user.set_password(n)
               user.save()
               error = "no"
            else:
                error="not"
        except:
            error="yes"


    return render(request,'change_password.html',locals())


def admin_login(request):
    error =""
    if request.method== 'POST':
        u = request.POST['username']
        p = request.POST['pwd']
        user = authenticate(username=u,password=p)
        try:
           if user.is_staff:
                login(request,user)
                error = "no"
           else:
            error = "yes"
        except:
            error="yes"
    return render(request,'admin_login.html',locals())

def admin_home(request):
    if not request.user.is_authenticated:
        return redirect('admin_login')
    return render(request,'admin_home.html')


def change_passwordadmin(request):
    if not request.user.is_authenticated:
        return redirect('admin_login')
    error =""

    user = request.user
    if request.method == "POST":
        c= request.POST['currentpassword']
        n= request.POST['newpassword']
        try:
            if user.check_password(c):
               user.set_password(n)
               user.save()
               error = "no"
            else:
                error="not"
        except:
            error="yes"


    return render(request,'change_passwordadmin.html',locals())

def all_student(request):
    if not request.user.is_authenticated:
        return redirect('admin_login')
    student= Student_Complaint.objects.all()
    return render(request,'all_student.html' ,locals())

def delete_student(request,pid):
    if not request.user.is_authenticated:
        return redirect('admin_login')
    user= User.objects.get(id=pid)
    user.delete()
    return redirect('all_student')

def edit_profile(request,pid):
    if not request.user.is_authenticated:
        return redirect('admin_login')
    error =""

    student= Student_Complaint.objects.get(id=pid)
    if request.method == "POST":
        fn = request.POST['firstname']
        ln = request.POST['lastname']
        si = request.POST['student_id']
        dept = request.POST['department']
        contact = request.POST['contact']
        studentcomplaint = request.POST['studentcomplaint']
        gender = request.POST['gender']

        student.user.first_name = fn
        student.user.last_name = ln
        student.user.student_id = si
        student.user.studentdept = dept
        student.user.contact = contact
        student.user.gender = gender

        if studentcomplaint:
            student.Student_complaint = studentcomplaint
        try:
            student.save()
            student.user.save()
            error = "no"
        except:
            error="yes"


    return render(request,'edit_profile.html',locals())









