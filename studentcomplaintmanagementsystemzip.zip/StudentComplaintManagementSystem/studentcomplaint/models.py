from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class Student_Complaint(models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    student_id= models.CharField(max_length=50)
    studentdept= models.CharField(max_length=100,null=True)
    contact= models.CharField(max_length=15,null=True)
    gender= models.CharField(max_length=50,null=True)
    Student_complaint= models.CharField(max_length=250,null=True)
    def __str__(self):
        return self.user.username

class StudentSuggestion(models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    studentcourse= models.CharField(max_length=100,null=True)
    studentsuggestion= models.CharField(max_length=200,null=True)

    def __str__(self):
        return self.user.username

class StudentCurrentYear(models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    collegename= models.CharField(max_length=100, null=True)
    studentcourse= models.CharField(max_length=100,null=True)
    studentdiv= models.CharField(max_length=100,null=True)

    def __str__(self):
        return self.user.username