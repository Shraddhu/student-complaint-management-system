from django.contrib import admin
from.models import *

# Register your models here.
admin.site.register(Student_Complaint)
admin.site.register(StudentSuggestion)
admin.site.register(StudentCurrentYear)